const { Events, MessageFlags, EmbedBuilder } = require('discord.js');
const { getGuild, updateGuild } = require('../utils/storage');
const {
  defaultPanel,
  getSession,
  deleteSession,
  buildPanelEmbed,
  buildPanelButtonRow,
  buildEditorPayload,
  buildFieldModal,
  applyFieldModal,
  buildRequestModal,
  missingPermissions,
  HEX_REGEX,
  normalizeHex,
} = require('../utils/panel');

const COOLDOWN_MS = (parseInt(process.env.REQUEST_COOLDOWN, 10) || 30) * 1000;
const cooldowns = new Map();

const EXPIRED_MSG = '⌛ Esta sesión del editor expiró o no es tuya. Usa `/set-channel-panel` de nuevo.';

async function safeReply(interaction, content) {
  const payload = { content, flags: MessageFlags.Ephemeral };
  try {
    if (interaction.replied || interaction.deferred) await interaction.followUp(payload);
    else await interaction.reply(payload);
  } catch (err) {
    console.error('[interaction] No se pudo responder:', err.message);
  }
}

// ---------- Editor del panel ----------

async function handleEditSelect(interaction) {
  const session = getSession(interaction.guildId, interaction.user.id);
  if (!session) return safeReply(interaction, EXPIRED_MSG);

  const field = interaction.values[0];
  const modal = buildFieldModal(field, session.panel);
  if (!modal) return safeReply(interaction, '❌ Opción no válida.');
  await interaction.showModal(modal);
}

async function handleColorSelect(interaction) {
  const session = getSession(interaction.guildId, interaction.user.id);
  if (!session) return safeReply(interaction, EXPIRED_MSG);

  const value = interaction.values[0];
  if (HEX_REGEX.test(value)) session.panel.color = normalizeHex(value);
  await interaction.update(buildEditorPayload(session, `🎨 Color cambiado a **${session.panel.color}**.`));
}

async function handleEditModal(interaction) {
  const session = getSession(interaction.guildId, interaction.user.id);
  if (!session) return safeReply(interaction, EXPIRED_MSG);

  const field = interaction.customId.split(':')[1];
  const draft = { ...session.panel };
  const result = applyFieldModal(field, interaction, draft);

  const notice = result.ok ? '✅ Cambios aplicados.' : `❌ ${result.error}`;
  if (result.ok) session.panel = draft;

  if (interaction.isFromMessage()) {
    await interaction.update(buildEditorPayload(session, notice));
  } else {
    await interaction.reply({ ...buildEditorPayload(session, notice), flags: MessageFlags.Ephemeral });
  }
}

async function handleReset(interaction) {
  const session = getSession(interaction.guildId, interaction.user.id);
  if (!session) return safeReply(interaction, EXPIRED_MSG);
  session.panel = defaultPanel();
  await interaction.update(buildEditorPayload(session, '♻️ Panel restablecido a los valores por defecto.'));
}

async function handleCancel(interaction) {
  deleteSession(interaction.guildId, interaction.user.id);
  await interaction.update({ content: '✖️ Edición cancelada. No se envió nada.', embeds: [], components: [] });
}

async function handleSend(interaction) {
  const session = getSession(interaction.guildId, interaction.user.id);
  if (!session) return safeReply(interaction, EXPIRED_MSG);

  const channel = await interaction.guild.channels.fetch(session.channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) {
    deleteSession(interaction.guildId, interaction.user.id);
    return interaction.update({
      content: '❌ El canal elegido ya no existe. Usa `/set-channel-panel` de nuevo.',
      embeds: [],
      components: [],
    });
  }

  const missing = missingPermissions(channel, interaction.guild.members.me);
  if (missing.length) {
    return interaction.update(
      buildEditorPayload(session, `❌ No tengo estos permisos en ${channel}: **${missing.join(', ')}**.`)
    );
  }

  let message;
  try {
    message = await channel.send({
      embeds: [buildPanelEmbed(session.panel)],
      components: [buildPanelButtonRow(session.panel)],
    });
  } catch (err) {
    console.error('[panel_send] Error enviando panel:', err);
    return interaction.update(
      buildEditorPayload(session, `❌ No se pudo enviar el panel: \`${err.message}\`. Revisa las URLs de imagen o el emoji.`)
    );
  }

  const config = updateGuild(interaction.guildId, {
    panel: session.panel,
    panelChannelId: channel.id,
    panelMessageId: message.id,
  });
  deleteSession(interaction.guildId, interaction.user.id);

  let content = `✅ Panel enviado correctamente a ${channel}. [Ver mensaje](${message.url})`;
  if (!config.formatChannelId) {
    content += '\n⚠️ Recuerda configurar el canal de llegada con `/set-format-channel`.';
  }
  await interaction.update({ content, embeds: [], components: [] });
}

// ---------- Peticiones de los usuarios ----------

async function handleRequestButton(interaction) {
  const config = getGuild(interaction.guildId);
  if (!config.formatChannelId) {
    return safeReply(
      interaction,
      '⚠️ El staff aún no ha configurado el canal de peticiones. Avisa a un administrador (`/set-format-channel`).'
    );
  }

  const key = `${interaction.guildId}:${interaction.user.id}`;
  const last = cooldowns.get(key) || 0;
  const remaining = last + COOLDOWN_MS - Date.now();
  if (remaining > 0) {
    return safeReply(interaction, `⏳ Espera **${Math.ceil(remaining / 1000)}s** antes de enviar otra petición.`);
  }

  await interaction.showModal(buildRequestModal(config.panel));
}

async function handleRequestModal(interaction) {
  const config = getGuild(interaction.guildId);
  const text = interaction.fields.getTextInputValue('format_text').trim();

  if (!text) return safeReply(interaction, '❌ El formato no puede estar vacío.');
  if (!config.formatChannelId) {
    return safeReply(interaction, '⚠️ El canal de peticiones no está configurado. Avisa a un administrador.');
  }

  const channel = await interaction.guild.channels.fetch(config.formatChannelId).catch(() => null);
  if (!channel || !channel.isTextBased()) {
    return safeReply(interaction, '❌ El canal de peticiones ya no existe. Avisa a un administrador.');
  }

  const missing = missingPermissions(channel, interaction.guild.members.me);
  if (missing.length) {
    return safeReply(interaction, `❌ No tengo permisos en el canal de peticiones (**${missing.join(', ')}**). Avisa al staff.`);
  }

  const panel = { ...defaultPanel(), ...(config.panel || {}) };
  const embed = new EmbedBuilder()
    .setTitle('🎵 Nueva petición de música')
    .setAuthor({
      name: interaction.member?.displayName || interaction.user.username,
      iconURL: interaction.user.displayAvatarURL(),
    })
    .setDescription(text)
    .addFields(
      { name: '👤 Usuario', value: `${interaction.user} (\`${interaction.user.username}\`)`, inline: true },
      { name: '🆔 ID', value: `\`${interaction.user.id}\``, inline: true }
    )
    .setColor(panel.color)
    .setThumbnail(interaction.user.displayAvatarURL())
    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() || undefined })
    .setTimestamp();

  try {
    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch (err) {
    console.error('[music_request] Error enviando petición:', err);
    return safeReply(interaction, '❌ No se pudo enviar tu petición. Inténtalo más tarde.');
  }

  cooldowns.set(`${interaction.guildId}:${interaction.user.id}`, Date.now());

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle('✅ ¡Petición enviada!')
        .setDescription('Tu formato se ha enviado correctamente. ¡Gracias! 🎶')
        .setColor('#2ECC71'),
    ],
    flags: MessageFlags.Ephemeral,
  });
}

// ---------- Enrutador ----------

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    if (!interaction.inGuild()) {
      if (interaction.isRepliable()) await safeReply(interaction, '❌ Este bot solo funciona dentro de servidores.');
      return;
    }

    try {
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return safeReply(interaction, '❌ Comando no encontrado.');
        return await command.execute(interaction);
      }

      if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'panel_edit_select') return await handleEditSelect(interaction);
        if (interaction.customId === 'panel_color_select') return await handleColorSelect(interaction);
        return;
      }

      if (interaction.isButton()) {
        switch (interaction.customId) {
          case 'panel_send': return await handleSend(interaction);
          case 'panel_reset': return await handleReset(interaction);
          case 'panel_cancel': return await handleCancel(interaction);
          case 'music_request': return await handleRequestButton(interaction);
          default: return;
        }
      }

      if (interaction.isModalSubmit()) {
        if (interaction.customId.startsWith('panel_modal:')) return await handleEditModal(interaction);
        if (interaction.customId === 'music_request_modal') return await handleRequestModal(interaction);
      }
    } catch (err) {
      console.error(`[interactionCreate] Error en ${interaction.customId || interaction.commandName}:`, err);
      await safeReply(interaction, '❌ Ocurrió un error inesperado. Inténtalo de nuevo.');
    }
  },
};