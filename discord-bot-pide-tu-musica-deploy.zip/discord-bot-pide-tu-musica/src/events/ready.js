const { Events, ActivityType } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ Conectado como ${client.user.tag} en ${client.guilds.cache.size} servidor(es).`);
    client.user.setActivity('🎵 Pide tu Música', { type: ActivityType.Listening });
  },
};