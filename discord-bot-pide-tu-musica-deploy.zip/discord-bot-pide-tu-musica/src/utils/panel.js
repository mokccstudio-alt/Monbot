const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionFlagsBits,
} = require('discord.js');

// ---------- Valores por defecto ----------

function defaultPanel() {
  return {
    title: '🎵 Pide tu Música',
    description:
      '¿Quieres escuchar algo en especial? Pulsa el botón de abajo, **escribe el formato** y dale a **Enviar**.\n\n' +
      '**Formato:**\n```\nCanción: \nArtista: \nEnlace (opcional): \n```',
    color: '#9B59B6',
    image: null,
    thumbnail: null,
    footer: 'Sistema de peticiones musicales',
    buttonLabel: 'Escribe el formato',
    buttonEmoji: '🎶',
    modalTitle: 'Pide tu Música',
    inputLabel: 'Escribe el formato',
    inputPlaceholder: 'Canción: ... | Artista: ... | Enlace: ...',
  };
}

const COLOR_PRESETS = [
  { label: 'Morado', value: '#9B59B6', emoji: '🟣' },
  { label: 'Azul', value: '#3498DB', emoji: '🔵' },
  { label: 'Blurple (Discord)', value: '#5865F2', emoji: '💠' },
  { label: 'Rojo', value: '#E74C3C', emoji: '🔴' },
  { label: 'Verde', value: '#2ECC71', emoji: '🟢' },
  { label: 'Amarillo', value: '#F1C40F', emoji: '🟡' },
  { label: 'Naranja', value: '#E67E22', emoji: '🟠' },
  { label: 'Rosa', value: '#FF69B4', emoji: '🌸' },
  { label: 'Negro', value: '#23272A', emoji: '⚫' },
  { label: 'Blanco', value: '#FFFFFE', emoji: '⚪' },
];

const EDIT_FIELDS = [
  { label: 'Título', value: 'titulo', description: 'Cambia el título del embed', emoji: '📝' },
  { label: 'Descripción', value: 'descripcion', description: 'Cambia el texto principal', emoji: '📄' },
  { label: 'Color personalizado', value: 'color', description: 'Color en formato HEX (#RRGGBB)', emoji: '🎨' },
  { label: 'Imagen grande', value: 'imagen', description: 'URL de una imagen (vacío = quitar)', emoji: '🖼️' },
  { label: 'Miniatura', value: 'miniatura', description: 'URL de una imagen pequeña (vacío = quitar)', emoji: '🔳' },
  { label: 'Pie de página', value: 'footer', description: 'Texto inferior (vacío = quitar)', emoji: '🔻' },
  { label: 'Botón del panel', value: 'boton', description: 'Texto y emoji del botón', emoji: '🔘' },
  { label: 'Formulario', value: 'formulario', description: 'Título, etiqueta y ejemplo del formulario', emoji: '🧾' },
];

// ---------- Sesiones del editor (en memoria) ----------

const SESSION_TTL = 30 * 60 * 1000; // 30 minutos sin actividad
const sessions = new Map();

function sessionKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

function createSession(guildId, userId, channelId, basePanel) {
  const session = {
    guildId,
    userId,
    channelId,
    panel: { ...defaultPanel(), ...(basePanel || {}) },
    updatedAt: Date.now(),
  };
  sessions.set(sessionKey(guildId, userId), session);
  return session;
}

function getSession(guildId, userId) {
  const key = sessionKey(guildId, userId);
  const session = sessions.get(key);
  if (!session) return null;
  if (Date.now() - session.updatedAt > SESSION_TTL) {
    sessions.delete(key);
    return null;
  }
  session.updatedAt = Date.now();
  return session;
}

function deleteSession(guildId, userId) {
  sessions.delete(sessionKey(guildId, userId));
}

setInterval(() => {
  const now = Date.now();
  for (const [key, s] of sessions) {
    if (now - s.updatedAt > SESSION_TTL) sessions.delete(key);
  }
}, 5 * 60 * 1000).unref();

// ---------- Utilidades ----------

const HEX_REGEX = /^#?[0-9a-fA-F]{6}$/;
const URL_REGEX = /^https?:\/\/\S+$/i;
const CUSTOM_EMOJI_REGEX = /^<(a?):(\w{2,32}):(\d{17,20})>$/;
const UNICODE_EMOJI_REGEX = /\p{Extended_Pictographic}|\p{Regional_Indicator}/u;

function normalizeHex(value) {
  const v = value.trim();
  return (v.startsWith('#') ? v : `#${v}`).toUpperCase();
}

function parseEmoji(str) {
  if (!str) return null;
  const custom = str.match(CUSTOM_EMOJI_REGEX);
  if (custom) return { animated: custom[1] === 'a', name: custom[2], id: custom[3] };
  return { name: str };
}

function isValidEmoji(str) {
  if (CUSTOM_EMOJI_REGEX.test(str)) return true;
  return str.length <= 16 && UNICODE_EMOJI_REGEX.test(str) && !/\s/.test(str);
}

function missingPermissions(channel, member) {
  const needed = [
    [PermissionFlagsBits.ViewChannel, 'Ver canal'],
    [PermissionFlagsBits.SendMessages, 'Enviar mensajes'],
    [PermissionFlagsBits.EmbedLinks, 'Insertar enlaces'],
  ];
  const perms = channel.permissionsFor(member);
  if (!perms) return needed.map((n) => n[1]);
  return needed.filter(([flag]) => !perms.has(flag)).map(([, name]) => name);
}

// ---------- Constructores ----------

function buildPanelEmbed(panel) {
  const embed = new EmbedBuilder()
    .setTitle(panel.title)
    .setDescription(panel.description)
    .setColor(panel.color);
  if (panel.image) embed.setImage(panel.image);
  if (panel.thumbnail) embed.setThumbnail(panel.thumbnail);
  if (panel.footer) embed.setFooter({ text: panel.footer });
  return embed;
}

function buildPanelButtonRow(panel, { preview = false } = {}) {
  const button = new ButtonBuilder()
    .setCustomId(preview ? 'panel_preview_button' : 'music_request')
    .setLabel(panel.buttonLabel)
    .setStyle(ButtonStyle.Primary);
  const emoji = parseEmoji(panel.buttonEmoji);
  if (emoji) button.setEmoji(emoji);
  if (preview) button.setDisabled(true);
  return new ActionRowBuilder().addComponents(button);
}

function buildEditorPayload(session, notice) {
  const { panel, channelId } = session;

  const fieldSelect = new StringSelectMenuBuilder()
    .setCustomId('panel_edit_select')
    .setPlaceholder('✏️ Elige qué quieres personalizar...')
    .addOptions(EDIT_FIELDS);

  const colorSelect = new StringSelectMenuBuilder()
    .setCustomId('panel_color_select')
    .setPlaceholder('🎨 Color rápido...')
    .addOptions(
      COLOR_PRESETS.map((c) => ({
        label: c.label,
        value: c.value,
        description: c.value,
        emoji: c.emoji,
        default: c.value.toUpperCase() === panel.color.toUpperCase(),
      }))
    );

  const actions = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('panel_send').setLabel('Enviar').setEmoji('📨').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('panel_reset').setLabel('Restablecer').setEmoji('♻️').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('panel_cancel').setLabel('Cancelar').setEmoji('✖️').setStyle(ButtonStyle.Danger)
  );

  let content =
    `## 🛠️ Editor del panel\n` +
    `Se enviará a <#${channelId}>. Personalízalo con los menús y pulsa **Enviar**.\n` +
    `*Vista previa del panel y de su botón:*`;
  if (notice) content = `${notice}\n\n${content}`;

  return {
    content,
    embeds: [buildPanelEmbed(panel)],
    components: [
      new ActionRowBuilder().addComponents(fieldSelect),
      new ActionRowBuilder().addComponents(colorSelect),
      buildPanelButtonRow(panel, { preview: true }),
      actions,
    ],
  };
}

function textInput(id, label, style, { value, required = true, max, min, placeholder } = {}) {
  const input = new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required);
  if (max) input.setMaxLength(max);
  if (min) input.setMinLength(min);
  if (placeholder) input.setPlaceholder(placeholder);
  if (value) input.setValue(String(value).slice(0, max || 4000));
  return new ActionRowBuilder().addComponents(input);
}

function buildFieldModal(field, panel) {
  const modal = new ModalBuilder().setCustomId(`panel_modal:${field}`);
  const S = TextInputStyle.Short;
  const P = TextInputStyle.Paragraph;

  switch (field) {
    case 'titulo':
      modal.setTitle('Editar título').addComponents(
        textInput('value', 'Título', S, { value: panel.title, max: 256 })
      );
      break;
    case 'descripcion':
      modal.setTitle('Editar descripción').addComponents(
        textInput('value', 'Descripción', P, { value: panel.description, max: 4000 })
      );
      break;
    case 'color':
      modal.setTitle('Color personalizado').addComponents(
        textInput('value', 'Color HEX (ej: #9B59B6)', S, { value: panel.color, max: 7, min: 6, placeholder: '#9B59B6' })
      );
      break;
    case 'imagen':
      modal.setTitle('Imagen grande').addComponents(
        textInput('value', 'URL de la imagen (vacío = quitar)', S, {
          value: panel.image, required: false, max: 1000, placeholder: 'https://...png',
        })
      );
      break;
    case 'miniatura':
      modal.setTitle('Miniatura').addComponents(
        textInput('value', 'URL de la miniatura (vacío = quitar)', S, {
          value: panel.thumbnail, required: false, max: 1000, placeholder: 'https://...png',
        })
      );
      break;
    case 'footer':
      modal.setTitle('Pie de página').addComponents(
        textInput('value', 'Texto del pie (vacío = quitar)', S, { value: panel.footer, required: false, max: 2048 })
      );
      break;
    case 'boton':
      modal.setTitle('Botón del panel').addComponents(
        textInput('label', 'Texto del botón', S, { value: panel.buttonLabel, max: 80 }),
        textInput('emoji', 'Emoji (vacío = sin emoji)', S, {
          value: panel.buttonEmoji, required: false, max: 64, placeholder: '🎶 o <:nombre:id>',
        })
      );
      break;
    case 'formulario':
      modal.setTitle('Formulario de petición').addComponents(
        textInput('modalTitle', 'Título del formulario', S, { value: panel.modalTitle, max: 45 }),
        textInput('inputLabel', 'Etiqueta del campo', S, { value: panel.inputLabel, max: 45 }),
        textInput('inputPlaceholder', 'Texto de ejemplo (placeholder)', S, {
          value: panel.inputPlaceholder, required: false, max: 100,
        })
      );
      break;
    default:
      return null;
  }
  return modal;
}

/**
 * Aplica los valores del modal al panel. Devuelve { ok: true } o { ok: false, error }.
 */
function applyFieldModal(field, interaction, panel) {
  const get = (id) => interaction.fields.getTextInputValue(id)?.trim() ?? '';

  switch (field) {
    case 'titulo': {
      const v = get('value');
      if (!v) return { ok: false, error: 'El título no puede estar vacío.' };
      panel.title = v;
      return { ok: true };
    }
    case 'descripcion': {
      const v = get('value');
      if (!v) return { ok: false, error: 'La descripción no puede estar vacía.' };
      panel.description = v;
      return { ok: true };
    }
    case 'color': {
      const v = get('value');
      if (!HEX_REGEX.test(v)) return { ok: false, error: 'Color inválido. Usa formato HEX, por ejemplo `#9B59B6`.' };
      panel.color = normalizeHex(v);
      return { ok: true };
    }
    case 'imagen':
    case 'miniatura': {
      const v = get('value');
      if (v && !URL_REGEX.test(v)) return { ok: false, error: 'La URL debe empezar por `http://` o `https://`.' };
      if (field === 'imagen') panel.image = v || null;
      else panel.thumbnail = v || null;
      return { ok: true };
    }
    case 'footer': {
      panel.footer = get('value') || null;
      return { ok: true };
    }
    case 'boton': {
      const label = get('label');
      const emoji = get('emoji');
      if (!label) return { ok: false, error: 'El texto del botón no puede estar vacío.' };
      if (emoji && !isValidEmoji(emoji)) {
        return { ok: false, error: 'Emoji inválido. Usa un emoji normal (🎶) o uno personalizado `<:nombre:id>`.' };
      }
      panel.buttonLabel = label;
      panel.buttonEmoji = emoji || null;
      return { ok: true };
    }
    case 'formulario': {
      const modalTitle = get('modalTitle');
      const inputLabel = get('inputLabel');
      if (!modalTitle || !inputLabel) return { ok: false, error: 'El título y la etiqueta son obligatorios.' };
      panel.modalTitle = modalTitle;
      panel.inputLabel = inputLabel;
      panel.inputPlaceholder = get('inputPlaceholder') || null;
      return { ok: true };
    }
    default:
      return { ok: false, error: 'Campo desconocido.' };
  }
}

function buildRequestModal(panel) {
  const p = { ...defaultPanel(), ...(panel || {}) };
  const input = new TextInputBuilder()
    .setCustomId('format_text')
    .setLabel(p.inputLabel.slice(0, 45))
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMinLength(2)
    .setMaxLength(1000);
  if (p.inputPlaceholder) input.setPlaceholder(p.inputPlaceholder.slice(0, 100));

  return new ModalBuilder()
    .setCustomId('music_request_modal')
    .setTitle(p.modalTitle.slice(0, 45))
    .addComponents(new ActionRowBuilder().addComponents(input));
}

module.exports = {
  defaultPanel,
  createSession,
  getSession,
  deleteSession,
  buildPanelEmbed,
  buildPanelButtonRow,
  buildEditorPayload,
  buildFieldModal,
  applyFieldModal,
  buildRequestModal,
  missingPermissions,
  normalizeHex,
  HEX_REGEX,
};