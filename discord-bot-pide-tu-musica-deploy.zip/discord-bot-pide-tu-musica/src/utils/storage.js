const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const FILE = path.join(DATA_DIR, 'config.json');

let cache = null;

function load() {
  if (cache) return cache;
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(FILE)) {
      const raw = fs.readFileSync(FILE, 'utf8');
      cache = raw.trim() ? JSON.parse(raw) : {};
    } else {
      cache = {};
    }
  } catch (err) {
    console.error('[storage] Error leyendo config.json, se usará una configuración vacía:', err.message);
    cache = {};
  }
  return cache;
}

function save() {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = `${FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(cache, null, 2), 'utf8');
    fs.renameSync(tmp, FILE);
  } catch (err) {
    console.error('[storage] Error guardando config.json:', err.message);
  }
}

function getGuild(guildId) {
  const data = load();
  return data[guildId] ? { ...data[guildId] } : {};
}

function updateGuild(guildId, patch) {
  const data = load();
  data[guildId] = { ...(data[guildId] || {}), ...patch };
  save();
  return { ...data[guildId] };
}

module.exports = { getGuild, updateGuild };