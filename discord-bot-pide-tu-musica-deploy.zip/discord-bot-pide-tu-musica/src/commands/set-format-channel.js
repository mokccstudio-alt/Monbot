const {
  SlashCommandBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
  EmbedBuilder,
} = require('discord.js');
const { updateGuild } = require('../utils/storage');
const { missingPermissions } = require('../utils/panel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-format-channel')
    .setDescription('Establece el canal donde llegarán los formatos enviados desde el panel.')
    .addChannelOption((opt) =>
      opt
        .setName('canal')
        .setDescription('Canal donde llegarán las peticiones de música')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const channel = interaction.options.getChannel('canal', true);

    const missing = missingPermissions(channel, interaction.guild.members.me);
    if (missing.length) {
      return interaction.reply({
        content: `❌ No tengo estos permisos en ${channel}: **${missing.join(', ')}**.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    updateGuild(interaction.guildId, { formatChannelId: channel.id });

    const embed = new EmbedBuilder()
      .setTitle('✅ Canal de formatos configurado')
      .setDescription(`A partir de ahora, cada formato enviado desde el panel llegará en estilo embed a ${channel}.`)
      .setColor('#2ECC71')
      .setTimestamp();

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};