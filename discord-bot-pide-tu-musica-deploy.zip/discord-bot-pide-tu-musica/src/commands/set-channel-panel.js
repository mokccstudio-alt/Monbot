const {
  SlashCommandBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
} = require('discord.js');
const { getGuild } = require('../utils/storage');
const { createSession, buildEditorPayload, missingPermissions } = require('../utils/panel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-channel-panel')
    .setDescription('Crea y personaliza el panel "Pide tu Música" y lo envía a un canal.')
    .addChannelOption((opt) =>
      opt
        .setName('canal')
        .setDescription('Canal donde se enviará el panel')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const channel = interaction.options.getChannel('canal', true);

    const missing = missingPermissions(channel, interaction.guild.members.me);
    if (missing.length) {
      return interaction.reply({
        content: `❌ No tengo estos permisos en ${channel}: **${missing.join(', ')}**.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    // Si ya se envió un panel antes, se parte de su diseño guardado
    const saved = getGuild(interaction.guildId).panel;
    const session = createSession(interaction.guildId, interaction.user.id, channel.id, saved);

    const config = getGuild(interaction.guildId);
    const notice = config.formatChannelId
      ? null
      : '⚠️ Aún no has configurado el canal donde llegarán los formatos. Usa `/set-format-channel`.';

    await interaction.reply({ ...buildEditorPayload(session, notice), flags: MessageFlags.Ephemeral });
  },
};