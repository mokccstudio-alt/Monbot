# 🎵 Bot "Pide tu Música"

Bot de Discord (discord.js v14) para recibir peticiones de música mediante un panel personalizable.

1. Un administrador crea y envía a un canal un **panel en estilo embed**. Lo personaliza con menús y botones.
2. Los usuarios pulsan el botón **"Escribe el formato"**, rellenan un formulario y le dan a **Enviar**.
3. Cada petición llega **en estilo embed** al canal configurado con el segundo comando.

> Discord no permite espacios ni mayúsculas en los comandos de barra. Por eso `/Set Channel Panel` es **`/set-channel-panel`** y `/Set Format Channel` es **`/set-format-channel`**.

## 📋 Comandos

| Comando | Descripción | Permiso |
|---|---|---|
| `/set-channel-panel canal:#canal` | Abre un editor privado para personalizar el panel y enviarlo al canal elegido. | Gestionar servidor |
| `/set-format-channel canal:#canal` | Define el canal donde llegarán en embed los formatos enviados por los usuarios. | Gestionar servidor |

### Editor del panel
- **Menú "Elige qué quieres personalizar"** sirve para cambiar estos elementos:
  - título, descripción y color HEX;
  - imagen grande, miniatura y pie de página;
  - texto y emoji del botón;
  - textos del formulario: título, etiqueta y ejemplo.
- **Menú "Color rápido"** ofrece colores predefinidos.
- **Botones:**
  - 📨 **Enviar** publica el panel en el canal elegido.
  - ♻️ **Restablecer** vuelve al diseño por defecto.
  - ✖️ **Cancelar** cierra el editor sin enviar nada.
- El editor muestra una vista previa en tiempo real del embed y de su botón.
- El último diseño enviado se guarda. La próxima vez que uses el comando, el editor parte de ese diseño.

### Funciones extra
- **Cooldown:** cada usuario debe esperar un tiempo entre peticiones. Por defecto son 30 s y se cambia con `REQUEST_COOLDOWN`.
- **Comprobación de permisos:** el bot verifica que tiene permisos en los canales antes de enviar.
- **Persistencia:** la configuración se guarda en `data/config.json`.

## ⚙️ Instalación local

Requisitos: **Node.js 18 o superior**.

```bash
git clone https://github.com/TU_USUARIO/TU_REPO.git
cd TU_REPO
npm install
cp .env.example .env    # en Windows: copy .env.example .env
```

Edita `.env`:
```
DISCORD_TOKEN=tu_token
CLIENT_ID=id_de_la_aplicacion
GUILD_ID=id_de_tu_servidor   # opcional: registra los comandos al instante
REQUEST_COOLDOWN=30
```

Registra los comandos y arranca el bot:
```bash
npm run deploy
npm start
```

## 🤖 Configuración en el Developer Portal

1. Entra en https://discord.com/developers/applications, crea una aplicación y ve a **Bot**.
2. Copia el **token** a `DISCORD_TOKEN`.
3. En **General Information**, copia el **Application ID** a `CLIENT_ID`.
4. **Intents:** el bot solo usa el intent `Guilds`, así que **no necesitas activar ningún Privileged Gateway Intent**.
5. **Invitación:** ve a **OAuth2 > URL Generator** y marca los scopes `bot` y `applications.commands`.
6. Marca estos permisos:
   - Ver canales
   - Enviar mensajes
   - Insertar enlaces
   - Leer historial de mensajes
7. Abre la URL generada para invitar el bot a tu servidor.

## 🐙 Subir a GitHub

```bash
git init
git add .
git commit -m "Bot Pide tu Música"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

> `.env` y `data/` están en `.gitignore`. **Nunca subas tu token.**

## 🚀 Despliegue

### Railway
1. Crea un proyecto con **New Project > Deploy from GitHub repo**.
2. En **Variables**, añade `DISCORD_TOKEN`, `CLIENT_ID` y, si quieres, `GUILD_ID` y `REQUEST_COOLDOWN`.
3. Start command: `npm start`.
4. Ejecuta `npm run deploy` una vez, en local o desde la consola de Railway.
5. Para conservar `data/config.json` entre despliegues, añade un **Volume** montado en `/app/data`.

### Render
1. Crea un servicio con **New > Background Worker** y conecta el repositorio.
2. Build command: `npm install`. Start command: `npm start`.
3. Añade las variables de entorno.
4. Si quieres persistencia, añade un **Disk** montado en la carpeta `data`.

### Discloud
1. Crea un archivo `discloud.config` en la raíz:
   ```
   NAME=PideTuMusica
   TYPE=bot
   MAIN=src/index.js
   RAM=100
   VERSION=latest
   ```
2. Comprime el proyecto sin `node_modules`, con tu `.env` incluido.
3. Súbelo con `.upload` en el servidor de Discloud o desde su panel web.

### VPS con pm2
```bash
git clone https://github.com/TU_USUARIO/TU_REPO.git && cd TU_REPO
npm install
nano .env              # rellena las variables
npm run deploy
npm install -g pm2
pm2 start src/index.js --name pide-tu-musica
pm2 save && pm2 startup
```

## 📁 Estructura

```
├── package.json
├── Procfile
├── .env.example
├── src/
│   ├── index.js
│   ├── deploy-commands.js
│   ├── commands/
│   │   ├── set-channel-panel.js
│   │   └── set-format-channel.js
│   ├── events/
│   │   ├── ready.js
│   │   └── interactionCreate.js
│   └── utils/
│       ├── panel.js
│       └── storage.js
└── data/config.json   (se crea automáticamente)
```

## ❓ Problemas comunes

- **No aparecen los comandos:** ejecuta `npm run deploy`. Sin `GUILD_ID`, los comandos globales pueden tardar hasta 1 hora en aparecer.
- **"No tengo permisos":** da al bot **Ver canal**, **Enviar mensajes** e **Insertar enlaces** en ese canal.
- **Error al enviar el panel:** revisa que las URLs de imagen sean válidas y que el emoji personalizado sea de un servidor donde esté el bot.